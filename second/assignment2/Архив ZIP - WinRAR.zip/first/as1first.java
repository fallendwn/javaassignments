package b.assignment1.first;

public class as1first {
    public static void main(String[] args){
        int[] intArray = new int[10];
        double[] doubleArray = new double[10];
    }
}
