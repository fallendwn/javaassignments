package b.assignment1.second;

public class as121 {
    public static void main(String[] args){
        printHydrogen();
        printJava();
    }
    public static void printHydrogen(){
        System.out.println("Hydrogen:");
        System.out.println("This is a chemical element of the periodic system with the designation H and atomic number 1.");
        System.out.println("Is the lightest element in the table.");
        System.out.println("Hydrogen is used in:");
        System.out.println("-Chemical industry;");
        System.out.println("-Oil refining industry;");
        System.out.println("-Aviation;");
        System.out.println("-Electricity.");
    }
    public static void printJava(){
        System.out.println("Java Island:");
        System.out.println("Included in Indonesia.");
        System.out.println("The states of Mataram, Majapahit, Demak originated on the island.");
                System.out.println("Java is the most populated island in the world:");
        System.out.println("The total population is 140 million people.");
        System.out.println("Population density - 1061 people/km²");
        System.out.println("One of the famous varieties of coffee, Kopi Luwak, is produced here.");
    }
}
