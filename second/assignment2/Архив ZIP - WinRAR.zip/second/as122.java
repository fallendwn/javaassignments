package b.assignment1.second;

public class as122 {
    public static void main(String[] args){
        System.out.println("I am a poet, my name is Tsvetik.");
        System.out.println("Hello from me to you all.");
    }
}
