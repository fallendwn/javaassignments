package b.assignment1.second;

public class as126 {
    public static void main(String[] args) {

    }
    public static void universalMethod(){
    }
    public static void universalMethod(int a){

    }
    public static void universalMethod(int a, float c){

    }
    public static void universalMethod(float a){

    }
    //4
    public static void universalMethod(double a){

    }
    public static void universalMethod(String a){

    }
    public static void universalMethod(char a){

    }
    public static void universalMethod(long a){

    }
    public static void universalMethod(int[] a){

    }
    public static void universalMethod(double a, String b){

    }
}
