package b.assignment1.second;

public class as128 {
    public static void main(String[] args){
        long a = 3;
        System.out.println(cube(a));

    }
    public static long cube(long a){
        a = a*a*a;
        return a;
    }
}
