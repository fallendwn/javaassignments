package b.assignment1.third;

import java.util.Scanner;
public class as131 {
    public static void main(String[] args) {
        String a= new String();
        String a1 = new String();
        String a2= new String();
        String a3= new String();
        String a4= new String();
        String a5= new String();
        String a6= new String();
        String a7= new String();
        String a8= new String();
        String a9= new String();

        int[] b = new int[]{};
        int[] b1 = new int[]{};
        int[] b2 = new int[]{};
        int[] b3 = new int[]{};

        Scanner scanner = new Scanner(System.in);
        Scanner scanner1 = new Scanner(System.in);
    }
}
