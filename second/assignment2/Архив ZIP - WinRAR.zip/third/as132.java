package b.assignment1.third;

public class as132 {
    public static void main(String[] args){

    }
    public class Human extends Terran{

    }
    public class Woman extends Human{

    }
    public class Terran{

    }
}
