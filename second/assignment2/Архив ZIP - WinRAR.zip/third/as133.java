package b.assignment1.third;

public class as133 {
    public class ElectricCar extends Car{
        int electricEnginePower;
    }
    public class Vehicle {
        double maxSpeed;
    }
    public class Car extends Vehicle {
        int wheelCount;
        double weight;
    }
}
